/* =========================================================
   لسان — النطق (تحويل النص لصوت) والتعرف على الكلام (تحدّث فعلي)
   ========================================================= */
(function (global) {
  'use strict';

  var ttsOK = 'speechSynthesis' in global;
  var SRClass = global.SpeechRecognition || global.webkitSpeechRecognition;

  function speak(text, lang) {
    if (!ttsOK || !text) return;
    try {
      global.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = lang || 'en-US';
      u.rate = 0.88;
      global.speechSynthesis.speak(u);
    } catch (e) {}
  }

  function listen(lang) {
    return new Promise(function (resolve, reject) {
      if (!SRClass) { reject('unsupported'); return; }
      try {
        var r = new SRClass();
        r.lang = lang || 'en-US';
        r.maxAlternatives = 3;
        r.interimResults = false;
        var done = false;
        r.onresult = function (e) {
          done = true;
          resolve(e.results[0][0].transcript);
        };
        r.onerror = function (e) { if (!done) reject(e.error || 'error'); };
        r.onend = function () { if (!done) reject('no-speech'); };
        r.start();
      } catch (e) { reject('unsupported'); }
    });
  }

  // مسافة ليفنشتاين لمقارنة النطق بتسامح
  function levenshtein(a, b) {
    a = a.toLowerCase(); b = b.toLowerCase();
    var m = a.length, n = b.length;
    var dp = new Array(n + 1);
    for (var j = 0; j <= n; j++) dp[j] = j;
    for (var i = 1; i <= m; i++) {
      var prev = dp[0]; dp[0] = i;
      for (j = 1; j <= n; j++) {
        var tmp = dp[j];
        dp[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[j], dp[j - 1]);
        prev = tmp;
      }
    }
    return dp[n];
  }
  function similarity(a, b) {
    if (!a || !b) return 0;
    var dist = levenshtein(a, b);
    return 1 - dist / Math.max(a.length, b.length);
  }

  global.Speech = {
    ttsSupported: ttsOK,
    sttSupported: !!SRClass,
    speak: speak,
    listen: listen,
    similarity: similarity
  };
})(window);

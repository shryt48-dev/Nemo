/* =========================================================
   محرك التكرار المتباعد (Spaced Repetition) — SM-2 مبسّط
   كل كلمة عندها "مستوى إتقان" من ٠ إلى ٧، وتاريخ استحقاق مراجعة
   ========================================================= */
(function (global) {
  'use strict';

  // فترات الإعادة بالأيام لكل مستوى إتقان
  var INTERVALS = [0, 1, 2, 4, 7, 15, 30, 60];
  var MAX_LEVEL = INTERVALS.length - 1;

  function dayMs() { return 86400000; }

  function newStat() {
    return { level: 0, due: Date.now(), seen: 0, correct: 0, lastAt: 0 };
  }

  // بعد إجابة صحيحة: يرتفع المستوى وتُبعّد المراجعة القادمة
  // بعد إجابة خاطئة: ينخفض المستوى وتُعاد المراجعة اليوم نفسه
  function update(stat, correct) {
    stat = stat || newStat();
    stat.seen += 1;
    stat.lastAt = Date.now();
    if (correct) {
      stat.correct += 1;
      stat.level = Math.min(MAX_LEVEL, stat.level + 1);
      stat.due = Date.now() + INTERVALS[stat.level] * dayMs();
    } else {
      stat.level = Math.max(0, stat.level - 2);
      stat.due = Date.now(); // مستحقة فورًا
    }
    return stat;
  }

  function isDue(stat) { return !stat || stat.due <= Date.now(); }

  function masteryPercent(stat) {
    if (!stat) return 0;
    return Math.round((stat.level / MAX_LEVEL) * 100);
  }

  global.SRS = {
    INTERVALS: INTERVALS,
    MAX_LEVEL: MAX_LEVEL,
    newStat: newStat,
    update: update,
    isDue: isDue,
    masteryPercent: masteryPercent
  };
})(window);

/* =========================================================
   لسان — الحفظ والتقدّم والألعاب التحفيزية (كله محليًا بالجهاز)
   ========================================================= */
(function (global) {
  'use strict';

  var KEY = 'lisan.v1';
  var state = null;
  var HEART_MAX = 5;
  var HEART_REGEN_MS = 4 * 60 * 60 * 1000; // قلب كل ٤ ساعات

  function todayKey() {
    var d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function isoWeekKey(d) {
    d = d ? new Date(d) : new Date();
    var t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    var day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    var yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    var week = Math.ceil((((t - yearStart) / 86400000) + 1) / 7);
    return t.getUTCFullYear() + '-W' + week;
  }

  function defaults() {
    return {
      activeLang: null,
      langs: {}, // langCode -> { completedNodes:[], wordStats:{ 't::key': stat } }
      xp: 0,
      gems: 20,
      hearts: HEART_MAX,
      heartUpdatedAt: Date.now(),
      streak: 0,
      longestStreak: 0,
      streakFreezes: 0,
      lastActiveDate: null,
      dailyGoal: 20,
      todayXP: 0,
      todayDate: todayKey(),
      weekKey: isoWeekKey(),
      weekXP: 0,
      leagueTier: 1,
      reviewsDone: 0,
      achievements: [], // ids earned
      installedAt: todayKey(),
      onboarded: false
    };
  }

  function deepMerge(base, extra) {
    for (var k in extra) {
      if (extra[k] && typeof extra[k] === 'object' && !Array.isArray(extra[k]) && base[k] && typeof base[k] === 'object') {
        deepMerge(base[k], extra[k]);
      } else if (extra[k] !== undefined) {
        base[k] = extra[k];
      }
    }
    return base;
  }

  function load() {
    if (state) return state;
    state = defaults();
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) deepMerge(state, JSON.parse(raw));
    } catch (e) { /* أول تشغيل */ }
    regenHearts();
    rolloverDay();
    return state;
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
  }

  function langState(code) {
    load();
    if (!state.langs[code]) state.langs[code] = { completedNodes: [], wordStats: {} };
    return state.langs[code];
  }

  function wordKey(langCode, wordT) { return langCode + '::' + wordT; }

  /* ---------- القلوب ---------- */
  function regenHearts() {
    if (state.hearts >= HEART_MAX) { state.heartUpdatedAt = Date.now(); return; }
    var elapsed = Date.now() - state.heartUpdatedAt;
    var gained = Math.floor(elapsed / HEART_REGEN_MS);
    if (gained > 0) {
      state.hearts = Math.min(HEART_MAX, state.hearts + gained);
      state.heartUpdatedAt = Date.now();
    }
  }
  function loseHeart() {
    load();
    state.hearts = Math.max(0, state.hearts - 1);
    if (state.hearts < HEART_MAX) state.heartUpdatedAt = Date.now();
    save();
    return state.hearts;
  }
  function refillHeartsWithGems(cost) {
    load();
    cost = cost || 10;
    if (state.gems < cost) return false;
    state.gems -= cost;
    state.hearts = HEART_MAX;
    save();
    return true;
  }
  function nextHeartInMs() {
    load();
    if (state.hearts >= HEART_MAX) return 0;
    return Math.max(0, HEART_REGEN_MS - (Date.now() - state.heartUpdatedAt));
  }

  /* ---------- اليوم/الأسبوع ---------- */
  function rolloverDay() {
    var t = todayKey();
    if (state.todayDate !== t) {
      state.todayDate = t;
      state.todayXP = 0;
    }
    var wk = isoWeekKey();
    if (state.weekKey !== wk) {
      state.weekKey = wk;
      state.weekXP = 0;
    }
  }

  function recordActivity() {
    load();
    var t = todayKey();
    if (state.lastActiveDate === t) return; // متسجل بالفعل اليوم
    var y = new Date(); y.setDate(y.getDate() - 1);
    var yKey = y.getFullYear() + '-' + String(y.getMonth() + 1).padStart(2, '0') + '-' + String(y.getDate()).padStart(2, '0');
    var dbefore = new Date(); dbefore.setDate(dbefore.getDate() - 2);
    var beforeKey = dbefore.getFullYear() + '-' + String(dbefore.getMonth() + 1).padStart(2, '0') + '-' + String(dbefore.getDate()).padStart(2, '0');

    if (state.lastActiveDate === yKey || state.lastActiveDate === null) {
      state.streak += 1;
    } else if (state.lastActiveDate === beforeKey && state.streakFreezes > 0) {
      state.streakFreezes -= 1; // تجميد السلسلة تلقائيًا ليوم فائت واحد
      state.streak += 1;
    } else {
      state.streak = 1;
    }
    state.lastActiveDate = t;
    state.longestStreak = Math.max(state.longestStreak, state.streak);
    save();
  }

  /* ---------- XP والجواهر ---------- */
  function addXP(n) {
    load();
    rolloverDay();
    state.xp += n;
    state.todayXP += n;
    state.weekXP += n;
    save();
  }
  function addGems(n) { load(); state.gems += n; save(); }
  function spendGems(n) {
    load();
    if (state.gems < n) return false;
    state.gems -= n; save(); return true;
  }
  function buyStreakFreeze() {
    load();
    if (!spendGems(20)) return false;
    state.streakFreezes += 1; save(); return true;
  }

  /* ---------- تقدّم الدروس ---------- */
  function isNodeComplete(langCode, nodeId) {
    return langState(langCode).completedNodes.indexOf(nodeId) !== -1;
  }
  function completeNode(langCode, nodeId) {
    var ls = langState(langCode);
    if (ls.completedNodes.indexOf(nodeId) === -1) ls.completedNodes.push(nodeId);
    save();
  }

  /* ---------- حالة الكلمات (SRS) ---------- */
  function getWordStat(langCode, wordT) {
    var ls = langState(langCode);
    return ls.wordStats[wordKey(langCode, wordT)] || null;
  }
  function updateWordStat(langCode, wordT, correct) {
    var ls = langState(langCode);
    var key = wordKey(langCode, wordT);
    var stat = SRS.update(ls.wordStats[key], correct);
    ls.wordStats[key] = stat;
    save();
    return stat;
  }
  function dueWords(langCode, words) {
    var ls = langState(langCode);
    return words.filter(function (wobj) {
      var stat = ls.wordStats[wordKey(langCode, wobj.t)];
      return stat && SRS.isDue(stat);
    });
  }
  function knownWords(langCode, words) {
    var ls = langState(langCode);
    return words.filter(function (wobj) { return !!ls.wordStats[wordKey(langCode, wobj.t)]; });
  }

  /* ---------- الإنجازات ---------- */
  var ACHIEVEMENTS = [
    { id: 'first_lesson', title: 'الخطوة الأولى', desc: 'أكملت أول درس', icon: '🎯' },
    { id: 'streak_7', title: 'أسبوع كامل', desc: 'سلسلة ٧ أيام متتالية', icon: '🔥' },
    { id: 'streak_30', title: 'شهر من الالتزام', desc: 'سلسلة ٣٠ يومًا متتالية', icon: '🏅' },
    { id: 'perfect_lesson', title: 'درس مثالي', desc: 'أكملت درسًا بدون أي خطأ', icon: '💯' },
    { id: 'polyglot', title: 'متعدد اللغات', desc: 'بدأت تعلّم لغتين أو أكثر', icon: '🌍' },
    { id: 'night_owl', title: 'بومة الليل', desc: 'أكملت درسًا بعد منتصف الليل', icon: '🦉' },
    { id: 'early_bird', title: 'طائر مبكر', desc: 'أكملت درسًا قبل السابعة صباحًا', icon: '🐦' },
    { id: 'gems_100', title: 'جامع الجواهر', desc: 'جمعت ١٠٠ جوهرة', icon: '💎' },
    { id: 'review_50', title: 'خبير المراجعة', desc: 'أكملت ٥٠ مراجعة', icon: '🧠' },
    { id: 'league_1st', title: 'قمة الدوري', desc: 'انتهيت بالمركز الأول في الدوري الأسبوعي', icon: '👑' }
  ];
  function unlockAchievement(id) {
    load();
    if (state.achievements.indexOf(id) === -1) {
      state.achievements.push(id);
      save();
      return true;
    }
    return false;
  }
  function checkAutoAchievements() {
    load();
    var newly = [];
    if (state.streak >= 7 && unlockAchievement('streak_7')) newly.push('streak_7');
    if (state.streak >= 30 && unlockAchievement('streak_30')) newly.push('streak_30');
    if (state.gems >= 100 && unlockAchievement('gems_100')) newly.push('gems_100');
    if (state.reviewsDone >= 50 && unlockAchievement('review_50')) newly.push('review_50');
    if (Object.keys(state.langs).length >= 2 && unlockAchievement('polyglot')) newly.push('polyglot');
    var h = new Date().getHours();
    if (h >= 0 && h < 5 && unlockAchievement('night_owl')) newly.push('night_owl');
    if (h >= 5 && h < 7 && unlockAchievement('early_bird')) newly.push('early_bird');
    return newly.map(function (id) { return ACHIEVEMENTS.filter(function (a) { return a.id === id; })[0]; });
  }

  function incrementReviews(n) { load(); state.reviewsDone += (n || 1); save(); }

  function setActiveLang(code) { load(); state.activeLang = code; save(); }
  function setDailyGoal(n) { load(); state.dailyGoal = n; save(); }
  function setOnboarded() { load(); state.onboarded = true; save(); }

  function resetAll() { state = defaults(); save(); }

  global.Store = {
    load: load, save: save, today: todayKey,
    langState: langState,
    hearts: function () { load(); return state.hearts; },
    loseHeart: loseHeart, refillHeartsWithGems: refillHeartsWithGems, nextHeartInMs: nextHeartInMs,
    addXP: addXP, addGems: addGems, spendGems: spendGems, buyStreakFreeze: buyStreakFreeze,
    isNodeComplete: isNodeComplete, completeNode: completeNode,
    getWordStat: getWordStat, updateWordStat: updateWordStat, dueWords: dueWords, knownWords: knownWords,
    recordActivity: recordActivity, incrementReviews: incrementReviews,
    ACHIEVEMENTS: ACHIEVEMENTS, unlockAchievement: unlockAchievement, checkAutoAchievements: checkAutoAchievements,
    setActiveLang: setActiveLang, setDailyGoal: setDailyGoal, setOnboarded: setOnboarded,
    resetAll: resetAll,
    raw: function () { return load(); }
  };
})(window);

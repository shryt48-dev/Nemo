/* =========================================================
   لسان — الواجهة والتنقّل ومحرّك تشغيل الدروس
   ========================================================= */
(function () {
  'use strict';

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var els = {};
  var toastTimer = null;
  var onbSelectedLang = null;
  var onbSelectedGoal = 20;

  /* ============ أدوات عامة ============ */
  function toast(msg) {
    var t = els.toast;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  function openSheet(html) {
    els.sheetIn.innerHTML = html;
    els.sheet.classList.add('show');
  }
  function closeSheet() { els.sheet.classList.remove('show'); }

  function hashStr(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) { h = (Math.imul(31, h) + s.charCodeAt(i)) | 0; }
    return h >>> 0;
  }
  function mulberry32(seed) {
    var a = seed;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ============ تبويبات ============ */
  var TABS = ['home', 'review', 'league', 'profile'];
  function showTab(name) {
    TABS.forEach(function (t) {
      $('#s-' + t).classList.toggle('active', t === name);
    });
    $$('.tabbar button').forEach(function (b) {
      b.classList.toggle('on', b.dataset.tab === name);
    });
    if (name === 'home') renderHome();
    if (name === 'review') renderReview();
    if (name === 'league') renderLeague();
    if (name === 'profile') renderProfile();
  }

  /* ============ شاشة الترحيب ============ */
  function renderOnboarding() {
    var wrap = $('#onb-langs');
    wrap.innerHTML = Data.LANGUAGES.map(function (l) {
      return '<button class="lang-card" data-code="' + l.code + '">' +
        '<span class="flag">' + l.flag + '</span><span class="lname">' + l.name + '</span></button>';
    }).join('');
    var goalWrap = $('#onb-goal');
    goalWrap.innerHTML = [10, 20, 50].map(function (g) {
      return '<button class="goal-chip' + (g === onbSelectedGoal ? ' picked' : '') + '" data-goal="' + g + '">' + g + ' XP</button>';
    }).join('');

    wrap.addEventListener('click', function (e) {
      var btn = e.target.closest('.lang-card');
      if (!btn) return;
      onbSelectedLang = btn.dataset.code;
      $$('.lang-card', wrap).forEach(function (c) { c.classList.toggle('picked', c === btn); });
      updateOnbStart();
    });
    goalWrap.addEventListener('click', function (e) {
      var btn = e.target.closest('.goal-chip');
      if (!btn) return;
      onbSelectedGoal = +btn.dataset.goal;
      $$('.goal-chip', goalWrap).forEach(function (c) { c.classList.toggle('picked', c === btn); });
    });
  }
  function updateOnbStart() {
    $('#onb-start').disabled = !onbSelectedLang;
  }

  function finishOnboarding() {
    Store.setActiveLang(onbSelectedLang);
    Store.setDailyGoal(onbSelectedGoal);
    Store.setOnboarded();
    Store.langState(onbSelectedLang); // تهيئة
    $('#s-onboarding').classList.remove('active');
    document.querySelector('.tabbar').style.display = 'flex';
    showTab('home');
  }

  /* ============ المسار الرئيسي ============ */
  function renderTopStats() {
    var st = Store.raw();
    $('#stat-streak').textContent = '🔥 ' + st.streak;
    $('#stat-gems').textContent = '💎 ' + st.gems;
    var heartsEl = $('#stat-hearts');
    heartsEl.textContent = '❤️ ' + Store.hearts();
    heartsEl.classList.toggle('low', Store.hearts() <= 1);
    var lang = Data.langMeta(st.activeLang);
    if (lang) $('#home-lang-btn').textContent = lang.flag + ' ' + lang.name;
    var pct = Math.min(100, Math.round((st.todayXP / st.dailyGoal) * 100));
    $('#dg-fill').style.width = pct + '%';
    $('#dg-label').textContent = st.todayXP + ' / ' + st.dailyGoal + ' XP اليوم';
  }

  function renderHome() {
    renderTopStats();
    var st = Store.raw();
    var langCode = st.activeLang;
    if (!langCode) return;
    var nodes = LessonEngine.buildNodes(langCode);
    var wrap = $('#path-wrap');
    var html = '';
    var lastUnit = null;
    var idx = 0;
    nodes.forEach(function (node) {
      if (node.unitId !== lastUnit) {
        html += '<div class="unit-banner">' + node.unitIcon + ' ' + node.unitTitle + '</div>';
        lastUnit = node.unitId;
        idx = 0;
      }
      var offsetClass = ['', 'node-offset-1', 'node-offset-2'][idx % 3];
      var cls = 'node ' + node.state + (node.kind === 'checkpoint' ? ' checkpoint' : '') + ' ' + offsetClass;
      var icon = node.state === 'locked' ? '🔒' : (node.kind === 'checkpoint' ? '🏆' : (node.state === 'done' ? '⭐' : node.unitIcon));
      html += '<button class="' + cls + '" data-node="' + node.id + '">' + icon + '</button>';
      idx++;
    });
    wrap.innerHTML = html;
    wrap.querySelectorAll('.node').forEach(function (btn) {
      btn.addEventListener('click', function () { onNodeClick(btn.dataset.node, nodes); });
    });
  }

  function onNodeClick(nodeId, nodes) {
    var node = nodes.filter(function (n) { return n.id === nodeId; })[0];
    if (!node) return;
    if (node.state === 'locked') { toast('أكمل الدرس السابق أولاً 🔒'); return; }
    var kindLabel = node.kind === 'checkpoint' ? 'تحدي المراجعة الشامل لهذه الوحدة' : 'درس جديد من ' + node.words.length + ' كلمات';
    openSheet(
      '<div class="sheet-icon">' + (node.kind === 'checkpoint' ? '🏆' : node.unitIcon) + '</div>' +
      '<div class="sheet-title">' + node.unitTitle + '</div>' +
      '<div class="sheet-desc">' + kindLabel + '</div>' +
      '<button class="btn-primary btn-big" id="sheet-start-lesson">' + (node.state === 'done' ? 'إعادة الدرس' : 'ابدأ الدرس') + '</button>'
    );
    $('#sheet-start-lesson').addEventListener('click', function () {
      closeSheet();
      startLesson(node);
    });
  }

  /* ============ محرّك تشغيل الدرس ============ */
  var session = null;

  function startLesson(node) {
    var st = Store.raw();
    var langCode = st.activeLang;
    var exercises = LessonEngine.generateExercises(node.words, langCode, { checkpoint: node.kind === 'checkpoint' });
    if (!exercises.length) { toast('لا توجد تمارين متاحة'); return; }
    session = {
      node: node, langCode: langCode, exercises: exercises, index: 0,
      mistakes: 0, correct: 0, isReview: false, mode: 'answer'
    };
    els.lesson.classList.add('show');
    renderExercise();
  }

  function startReview(words) {
    var st = Store.raw();
    var exercises = LessonEngine.generateExercises(words, st.activeLang, {});
    if (!exercises.length) { toast('لا توجد كلمات جاهزة للمراجعة بعد'); return; }
    session = {
      node: null, langCode: st.activeLang, exercises: exercises, index: 0,
      mistakes: 0, correct: 0, isReview: true, mode: 'answer'
    };
    els.lesson.classList.add('show');
    renderExercise();
  }

  function updateLessonChrome() {
    var pct = Math.round((session.index / session.exercises.length) * 100);
    $('#lesson-progress').style.width = pct + '%';
    var hearts = Store.hearts();
    $('#lesson-hearts').textContent = '❤️'.repeat(hearts) + '🖤'.repeat(5 - hearts);
  }

  function renderExercise() {
    var ex = session.exercises[session.index];
    var body = $('#lesson-body');
    var lang = Data.langMeta(session.langCode);
    session.mode = 'answer';
    session.given = null;
    session.arrangeChosen = [];
    session.matchState = { picked: null, matched: 0 };
    updateLessonChrome();
    $('#lesson-feedback').textContent = '';
    $('#lesson-feedback').className = 'lfeedback';
    var check = $('#lesson-check');
    check.textContent = 'تحقّق';
    check.disabled = true;
    check.style.display = '';

    if (ex.type === 'choice') {
      body.innerHTML =
        '<div class="ex-title">اختر الترجمة الصحيحة</div>' +
        '<div class="ex-prompt">' + ex.prompt + '</div>' +
        '<div class="opt-grid">' + ex.options.map(function (o) {
          return '<button class="opt" data-v="' + escapeAttr(o) + '">' + o + '</button>';
        }).join('') + '</div>';
      bindChoiceOptions();
    } else if (ex.type === 'choice_reverse') {
      body.innerHTML =
        '<div class="ex-title">اختر المعنى الصحيح</div>' +
        '<div class="ex-prompt">' + ex.prompt + '</div>' +
        '<div class="ex-audio"><button id="ex-play">🔊</button></div>' +
        '<div class="opt-grid">' + ex.options.map(function (o) {
          return '<button class="opt" data-v="' + escapeAttr(o) + '">' + o + '</button>';
        }).join('') + '</div>';
      $('#ex-play').addEventListener('click', function () { Speech.speak(ex.word.script || ex.word.t, lang.speech); });
      bindChoiceOptions();
    } else if (ex.type === 'arrange') {
      body.innerHTML =
        '<div class="ex-title">رتّب الجملة</div>' +
        '<div class="ex-prompt">' + ex.prompt + '</div>' +
        '<div class="arrange-answer" id="arrange-answer"></div>' +
        '<div class="arrange-bank" id="arrange-bank">' + ex.tokens.map(function (tok, i) {
          return '<button class="token" data-i="' + i + '">' + tok + '</button>';
        }).join('') + '</div>';
      bindArrange(ex);
    } else if (ex.type === 'listen') {
      body.innerHTML =
        '<div class="ex-title">استمع واكتب ما تسمعه</div>' +
        '<div class="ex-audio"><button id="ex-play">🔊</button></div>' +
        '<input class="type-input" id="type-answer" placeholder="اكتب هنا..." autocomplete="off" autocapitalize="off" spellcheck="false">';
      var playFn = function () { Speech.speak(ex.speakText, lang.speech); };
      $('#ex-play').addEventListener('click', playFn);
      setTimeout(playFn, 350);
      var input = $('#type-answer');
      input.addEventListener('input', function () {
        session.given = input.value;
        check.disabled = !input.value.trim();
      });
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !check.disabled) onCheck(); });
    } else if (ex.type === 'speak') {
      body.innerHTML =
        '<div class="ex-title">انطق الكلمة أو الجملة التالية</div>' +
        '<div class="ex-prompt">' + ex.prompt + '</div>' +
        '<div class="ex-audio"><button id="ex-play">🔊</button></div>' +
        '<button class="speak-mic" id="ex-mic">🎙️</button>' +
        '<div class="speak-hint" id="speak-hint">اضغط على الميكروفون وانطق بصوت واضح</div>';
      $('#ex-play').addEventListener('click', function () { Speech.speak(ex.speakText, lang.speech); });
      check.style.display = 'none';
      $('#ex-mic').addEventListener('click', function () { runSpeakExercise(ex); });
    } else if (ex.type === 'match') {
      var cards = [];
      ex.pairs.forEach(function (p, i) { cards.push({ side: 't', text: p.t, key: p.key, i: i }); cards.push({ side: 'a', text: p.a, key: p.key, i: i }); });
      cards = LessonEngine.shuffle(cards);
      body.innerHTML =
        '<div class="ex-title">طابق كل كلمة بمعناها</div>' +
        '<div class="match-grid" id="match-grid">' + cards.map(function (c, idx) {
          return '<button class="match-card" data-key="' + escapeAttr(c.key) + '" data-idx="' + idx + '">' + c.text + '</button>';
        }).join('') + '</div>';
      check.style.display = 'none';
      bindMatch(ex, cards.length);
    }
  }

  function escapeAttr(s) { return (s || '').replace(/"/g, '&quot;'); }

  function bindChoiceOptions() {
    var body = $('#lesson-body');
    body.querySelectorAll('.opt').forEach(function (btn) {
      btn.addEventListener('click', function () {
        body.querySelectorAll('.opt').forEach(function (b) { b.classList.remove('selected'); });
        btn.classList.add('selected');
        session.given = btn.dataset.v;
        $('#lesson-check').disabled = false;
      });
    });
  }

  function bindArrange(ex) {
    var answerBox = $('#arrange-answer');
    var bank = $('#arrange-bank');
    function refreshAnswer() {
      answerBox.innerHTML = session.arrangeChosen.map(function (i) {
        return '<button class="token" data-i="' + i + '">' + ex.tokens[i] + '</button>';
      }).join('');
      $$('.token', answerBox).forEach(function (btn) {
        btn.addEventListener('click', function () {
          var i = +btn.dataset.i;
          session.arrangeChosen = session.arrangeChosen.filter(function (x) { return x !== i; });
          refreshAnswer();
          syncBank();
        });
      });
      session.given = session.arrangeChosen.map(function (i) { return ex.tokens[i]; }).join(' ');
      $('#lesson-check').disabled = session.arrangeChosen.length !== ex.tokens.length;
    }
    function syncBank() {
      $$('.token', bank).forEach(function (btn) {
        var i = +btn.dataset.i;
        btn.classList.toggle('used', session.arrangeChosen.indexOf(i) !== -1);
      });
    }
    $$('.token', bank).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var i = +btn.dataset.i;
        if (session.arrangeChosen.indexOf(i) !== -1) return;
        session.arrangeChosen.push(i);
        refreshAnswer();
        syncBank();
      });
    });
  }

  function bindMatch(ex, totalCards) {
    var grid = $('#match-grid');
    grid.querySelectorAll('.match-card').forEach(function (card) {
      card.addEventListener('click', function () {
        if (card.classList.contains('matched') || card === session.matchState.picked) return;
        if (!session.matchState.picked) {
          card.classList.add('selected');
          session.matchState.picked = card;
          return;
        }
        var a = session.matchState.picked, b = card;
        if (a.dataset.key === b.dataset.key && a !== b) {
          a.classList.add('matched'); b.classList.add('matched');
          a.classList.remove('selected'); b.classList.remove('selected');
          session.matchState.matched += 2;
          session.matchState.picked = null;
          if (session.matchState.matched >= totalCards) {
            ex.pairs.forEach(function (p) { Store.updateWordStat(session.langCode, p.key, true); });
            session.correct++;
            markExerciseAnswered(true, true);
          }
        } else {
          a.classList.add('shake'); b.classList.add('shake');
          setTimeout(function () {
            a.classList.remove('selected', 'shake'); b.classList.remove('shake');
            session.matchState.picked = null;
          }, 320);
        }
      });
    });
  }

  function runSpeakExercise(ex) {
    var mic = $('#ex-mic'), hint = $('#speak-hint');
    mic.classList.add('listening');
    hint.textContent = 'بنسمعك...';
    var lang = Data.langMeta(session.langCode);
    Speech.listen(lang.speech).then(function (transcript) {
      mic.classList.remove('listening');
      var ok = Speech.similarity(LessonEngine.norm(transcript), LessonEngine.norm(ex.answer)) >= 0.55;
      handleAnswerResult(ok, ex);
    }).catch(function () {
      mic.classList.remove('listening');
      hint.textContent = 'ما قدرناش نسمعك، جرّب تاني أو تأكد من إذن الميكروفون';
    });
  }

  function onCheck() {
    if (session.mode === 'answer') {
      var ex = session.exercises[session.index];
      var ok = LessonEngine.checkAnswer(ex, session.given);
      handleAnswerResult(ok, ex);
    } else {
      nextExercise();
    }
  }

  function disableExerciseInputs() {
    $$('.opt', document).forEach(function (b) { b.style.pointerEvents = 'none'; });
    $$('.token', document).forEach(function (b) { b.style.pointerEvents = 'none'; });
    var input = $('#type-answer');
    if (input) input.disabled = true;
  }

  function handleAnswerResult(ok, ex) {
    disableExerciseInputs();
    var fb = $('#lesson-feedback');
    if (ex.word) Store.updateWordStat(session.langCode, ex.word.t, ok);
    if (ok) {
      session.correct++;
      fb.textContent = 'صح! 🎉';
      fb.className = 'lfeedback ok';
      if (ex.type === 'choice' || ex.type === 'choice_reverse') {
        $$('.opt', document).forEach(function (b) { if (b.dataset.v === ex.answer) b.classList.add('correct'); });
      }
    } else {
      session.mistakes++;
      var left = Store.loseHeart();
      fb.textContent = 'مش تمام، الصح: ' + ex.answer;
      fb.className = 'lfeedback bad';
      if (ex.type === 'choice' || ex.type === 'choice_reverse') {
        $$('.opt', document).forEach(function (b) {
          if (b.classList.contains('selected')) b.classList.add('wrong');
          if (b.dataset.v === ex.answer) b.classList.add('correct');
        });
      }
      renderTopStats();
      updateLessonChrome();
      if (left <= 0) {
        setTimeout(function () { showLessonFailed(); }, 700);
        return;
      }
    }
    markExerciseAnswered(ok, false);
  }

  function markExerciseAnswered() {
    session.mode = 'continue';
    var check = $('#lesson-check');
    check.style.display = '';
    check.textContent = session.index >= session.exercises.length - 1 ? 'إنهاء' : 'متابعة';
    check.disabled = false;
  }

  function nextExercise() {
    session.index++;
    if (session.index >= session.exercises.length) { finishLesson(); return; }
    renderExercise();
  }

  function showLessonFailed() {
    els.lesson.classList.remove('show');
    openSheet(
      '<div class="sheet-icon">💔</div>' +
      '<div class="sheet-title">خلصت قلوبك</div>' +
      '<div class="sheet-desc">تقدر تكمل بجوهرتين مقابل ١٠ جواهر، أو تعيد الدرس من البداية.</div>' +
      '<button class="btn-primary btn-big" id="btn-refill" style="margin-bottom:10px">أعد القلوب (١٠ 💎)</button>' +
      '<button class="btn-ghost" id="btn-restart">أعد المحاولة</button>'
    );
    $('#btn-refill').addEventListener('click', function () {
      if (Store.refillHeartsWithGems(10)) {
        closeSheet();
        renderTopStats();
        els.lesson.classList.add('show');
        renderExercise();
      } else {
        toast('جواهرك مش كفاية 💎');
      }
    });
    $('#btn-restart').addEventListener('click', function () {
      closeSheet();
      var node = session.node, isReview = session.isReview;
      if (isReview) {
        renderReview();
        showTab('review');
      } else {
        startLesson(node);
      }
    });
  }

  function finishLesson() {
    var perfect = session.mistakes === 0;
    var xp = session.correct * 10 + (perfect ? 15 : 0);
    var gems = 5 + (session.node && session.node.kind === 'checkpoint' ? 15 : 0) + (perfect ? 10 : 0);
    var hadCompletedBefore = totalCompletedNodesCount() > 0;

    Store.addXP(xp);
    Store.addGems(gems);
    Store.recordActivity();
    if (session.isReview) {
      Store.incrementReviews(session.exercises.length);
    } else if (session.node) {
      Store.completeNode(session.langCode, session.node.id);
    }

    var newAch = [];
    if (!session.isReview && !hadCompletedBefore && Store.unlockAchievement('first_lesson')) {
      newAch.push(Store.ACHIEVEMENTS.filter(function (a) { return a.id === 'first_lesson'; })[0]);
    }
    if (perfect && Store.unlockAchievement('perfect_lesson')) {
      newAch.push(Store.ACHIEVEMENTS.filter(function (a) { return a.id === 'perfect_lesson'; })[0]);
    }
    newAch = newAch.concat(Store.checkAutoAchievements());

    els.lesson.classList.remove('show');
    renderTopStats();

    var achHtml = newAch.length ? '<div class="section-title">إنجازات جديدة 🎊</div>' +
      newAch.map(function (a) { return '<div style="margin-bottom:6px">' + a.icon + ' <b>' + a.title + '</b> — ' + a.desc + '</div>'; }).join('') : '';

    openSheet(
      '<div class="sheet-icon">' + (perfect ? '🌟' : '✅') + '</div>' +
      '<div class="sheet-title">' + (perfect ? 'درس مثالي!' : 'أحسنت!') + '</div>' +
      '<div class="sheet-xp">' +
      '<div class="b"><b>+' + xp + '</b><span>XP</span></div>' +
      '<div class="b"><b>+' + gems + '</b><span>💎</span></div>' +
      '<div class="b"><b>' + session.correct + '/' + session.exercises.length + '</b><span>صحيح</span></div>' +
      '</div>' + achHtml +
      '<button class="btn-primary btn-big" id="sheet-continue">متابعة</button>'
    );
    $('#sheet-continue').addEventListener('click', function () {
      closeSheet();
      showTab(session.isReview ? 'review' : 'home');
      session = null;
    });
  }

  function totalCompletedNodesCount() {
    var st = Store.raw();
    var n = 0;
    Object.keys(st.langs).forEach(function (code) { n += st.langs[code].completedNodes.length; });
    return n;
  }

  /* ============ المراجعة ============ */
  function renderReview() {
    var st = Store.raw();
    var langCode = st.activeLang;
    if (!langCode) return;
    var pool = Data.allWords(langCode);
    var due = Store.dueWords(langCode, pool);
    var known = Store.knownWords(langCode, pool);
    var body = $('#review-body');
    if (!known.length) {
      body.innerHTML = '<div class="review-card"><div class="n">📭</div><p>لسه ما بدأتش أي درس. أكمل درسًا الأول عشان تقدر تراجع كلماته.</p></div>';
      return;
    }
    body.innerHTML =
      '<div class="review-card">' +
      '<div class="n">' + due.length + '</div>' +
      '<p>كلمة مستحقة المراجعة دلوقتي، من إجمالي ' + known.length + ' كلمة اتعلمتها</p>' +
      '<button class="btn-primary btn-big" id="btn-start-review">ابدأ المراجعة</button>' +
      '</div>';
    $('#btn-start-review').addEventListener('click', function () {
      var words = due.length ? due : known;
      startReview(LessonEngine.shuffle(words).slice(0, 10));
    });
  }

  /* ============ الدوري الأسبوعي ============ */
  var BOT_NAMES = ['نور', 'سامر', 'ليان', 'آدم', 'ملك', 'يوسف', 'جود', 'رهف', 'كريم'];
  var BOT_AVATARS = ['🦊', '🐨', '🐼', '🦁', '🐸', '🐵', '🐯', '🐰', '🦄'];

  function renderLeague() {
    var st = Store.raw();
    var seed = hashStr(st.weekKey + '-league');
    var rand = mulberry32(seed);
    var rows = BOT_NAMES.map(function (name, i) {
      return { name: name, avatar: BOT_AVATARS[i], xp: Math.floor(rand() * 380) + 15, me: false };
    });
    rows.push({ name: 'أنت', avatar: '😎', xp: st.weekXP, me: true });
    rows.sort(function (a, b) { return b.xp - a.xp; });

    var body = $('#league-body');
    body.innerHTML =
      '<div class="league-note">دوري المستوى ' + st.leagueTier + ' — أعلى ٣ يترقّون للمستوى التالي كل أسبوع 🔥</div>' +
      rows.map(function (r, i) {
        var zone = i < 3 ? 'zone-up' : (i >= rows.length - 3 ? 'zone-down' : '');
        return '<div class="league-row ' + zone + (r.me ? ' me' : '') + '">' +
          '<div class="league-rank">' + (i + 1) + '</div>' +
          '<div class="league-avatar">' + r.avatar + '</div>' +
          '<div class="league-name">' + r.name + '</div>' +
          '<div class="league-xp">' + r.xp + ' XP</div>' +
          '</div>';
      }).join('');

    if (rows[0].me) Store.unlockAchievement('league_1st');
  }

  /* ============ حسابي ============ */
  function renderProfile() {
    var st = Store.raw();
    var body = $('#profile-body');
    var startedCodes = Object.keys(st.langs);
    var langRows = Data.LANGUAGES.map(function (l) {
      var started = startedCodes.indexOf(l.code) !== -1;
      var active = st.activeLang === l.code;
      var wordsCount = started ? Object.keys(st.langs[l.code].wordStats).length : 0;
      return '<div class="lang-row' + (active ? ' active' : '') + '" data-code="' + l.code + '">' +
        '<div class="flag">' + l.flag + '</div>' +
        '<div class="info"><b>' + l.name + '</b><span>' + (started ? wordsCount + ' كلمة متعلَّمة' : 'لم تبدأ بعد') + '</span></div>' +
        (active ? '<span>✅</span>' : '<span>▶️</span>') +
        '</div>';
    }).join('');

    var achHtml = Store.ACHIEVEMENTS.map(function (a) {
      var on = st.achievements.indexOf(a.id) !== -1;
      return '<div class="ach' + (on ? ' on' : '') + '" title="' + a.desc + '"><div class="ic">' + a.icon + '</div><div class="t">' + a.title + '</div></div>';
    }).join('');

    body.innerHTML =
      '<div class="profile-stats">' +
      '<div class="pstat"><div class="v">' + st.xp + '</div><div class="l">إجمالي XP</div></div>' +
      '<div class="pstat"><div class="v">' + st.longestStreak + '</div><div class="l">أطول سلسلة 🔥</div></div>' +
      '<div class="pstat"><div class="v">' + st.gems + '</div><div class="l">الجواهر 💎</div></div>' +
      '</div>' +
      '<div class="section-title">الهدف اليومي</div>' +
      '<div class="goal-picker" id="profile-goal">' + [10, 20, 50, 100].map(function (g) {
        return '<button class="goal-chip' + (st.dailyGoal === g ? ' picked' : '') + '" data-goal="' + g + '">' + g + ' XP</button>';
      }).join('') + '</div>' +
      '<div class="section-title">تجميد السلسلة (' + st.streakFreezes + ' متاح)</div>' +
      '<button class="btn-ghost" id="buy-freeze">اشترِ تجميدة بـ ٢٠ 💎</button>' +
      '<div class="section-title">لغاتي</div>' +
      '<div class="lang-list">' + langRows + '</div>' +
      '<div class="section-title">الإنجازات</div>' +
      '<div class="ach-grid">' + achHtml + '</div>';

    $('#profile-goal').addEventListener('click', function (e) {
      var btn = e.target.closest('.goal-chip');
      if (!btn) return;
      Store.setDailyGoal(+btn.dataset.goal);
      renderProfile();
    });
    $('#buy-freeze').addEventListener('click', function () {
      if (Store.buyStreakFreeze()) { toast('تم شراء تجميدة السلسلة 🧊'); renderProfile(); }
      else toast('جواهرك مش كفاية 💎');
    });
    $$('.lang-row', body).forEach(function (row) {
      row.addEventListener('click', function () {
        var code = row.dataset.code;
        Store.setActiveLang(code);
        Store.langState(code);
        toast('اتحوّلت لـ ' + Data.langMeta(code).name);
        renderProfile();
      });
    });
  }

  /* ============ التهيئة ============ */
  function bindStaticEvents() {
    $$('.tabbar button').forEach(function (b) {
      b.addEventListener('click', function () { showTab(b.dataset.tab); });
    });
    els.sheet.addEventListener('click', function (e) { if (e.target === els.sheet) closeSheet(); });
    $('#lesson-close').addEventListener('click', function () {
      if (confirmLike()) { els.lesson.classList.remove('show'); session = null; }
    });
    $('#lesson-check').addEventListener('click', onCheck);
    $('#onb-start').addEventListener('click', finishOnboarding);
    $('#home-lang-btn').addEventListener('click', function () { showTab('profile'); });
  }
  function confirmLike() { return true; }

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    els.sheet = $('#sheet');
    els.sheetIn = $('#sheet-in');
    els.toast = $('#toast');
    els.lesson = $('#lesson');

    bindStaticEvents();
    var st = Store.load();
    if (st.onboarded && st.activeLang) {
      $('#s-onboarding').classList.remove('active');
      document.querySelector('.tabbar').style.display = 'flex';
      showTab('home');
    } else {
      document.querySelector('.tabbar').style.display = 'none';
      renderOnboarding();
    }
  });
})();

/* =========================================================
   لسان — محرّك بناء المسار وتوليد التمارين ديناميكيًا من المفردات
   ========================================================= */
(function (global) {
  'use strict';

  var CHUNK = 4; // عدد كلمات كل درس

  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function sample(arr, n) { return shuffle(arr).slice(0, n); }
  function norm(s) {
    return (s || '').toString().trim().toLowerCase()
      .replace(/[.,!?؟،؛;:'"()\-]/g, '')
      .replace(/\s+/g, ' ');
  }

  /* ---------- بناء عقد المسار ---------- */
  function buildNodes(langCode) {
    var units = Data.courseFor(langCode);
    var nodes = [];
    units.forEach(function (unit) {
      var chunks = [];
      for (var i = 0; i < unit.words.length; i += CHUNK) chunks.push(unit.words.slice(i, i + CHUNK));
      chunks.forEach(function (chunk, idx) {
        nodes.push({
          id: unit.id + '-l' + idx,
          unitId: unit.id,
          unitTitle: unit.title,
          unitIcon: unit.icon,
          kind: 'lesson',
          words: chunk
        });
      });
      nodes.push({
        id: unit.id + '-checkpoint',
        unitId: unit.id,
        unitTitle: unit.title,
        unitIcon: '🏆',
        kind: 'checkpoint',
        words: unit.words
      });
    });

    var completed = Store.langState(langCode).completedNodes;
    var unlockedFound = false;
    nodes.forEach(function (node, i) {
      node.done = completed.indexOf(node.id) !== -1;
      if (node.done) { node.state = 'done'; return; }
      if (!unlockedFound) { node.state = 'available'; unlockedFound = true; }
      else node.state = 'locked';
    });
    return nodes;
  }

  /* ---------- توليد التمارين ---------- */
  function buildDistractors(word, pool, count) {
    var others = pool.filter(function (p) { return p.t !== word.t; });
    return sample(others, count).map(function (p) { return p.a; });
  }
  function buildDistractorsTarget(word, pool, count) {
    var others = pool.filter(function (p) { return p.t !== word.t; });
    return sample(others, count).map(function (p) { return p.t; });
  }

  function generateExercises(words, langCode, opts) {
    opts = opts || {};
    var pool = Data.allWords(langCode);
    var ex = [];

    words.forEach(function (word) {
      // ١. اختر الترجمة الصحيحة (عربي -> هدف)
      var optsT = shuffle([word.t].concat(buildDistractorsTarget(word, pool, 3)));
      ex.push({ type: 'choice', prompt: word.a, options: optsT, answer: word.t, word: word });

      // ٢. اختر المعنى الصحيح (هدف -> عربي)
      var optsA = shuffle([word.a].concat(buildDistractors(word, pool, 3)));
      ex.push({ type: 'choice_reverse', prompt: word.script || word.t, options: optsA, answer: word.a, word: word });
    });

    // ٣. جمل مرتّبة (للكلمات التي عندها جملة مثال)
    var withExamples = words.filter(function (wd) { return wd.et; });
    withExamples.forEach(function (word) {
      var tokens = word.et.split(' ');
      ex.push({ type: 'arrange', prompt: word.ea, tokens: shuffle(tokens), answer: tokens.join(' '), word: word });
    });

    // ٤. إملاء بالاستماع
    sample(words, Math.max(1, Math.ceil(words.length / 2))).forEach(function (word) {
      ex.push({ type: 'listen', speakText: word.script || word.t, answer: word.t, word: word });
    });

    // ٥. تحدّث فعلي (لو المتصفح يدعم التعرف على الصوت)
    if (Speech.sttSupported) {
      sample(words, Math.max(1, Math.ceil(words.length / 2))).forEach(function (word) {
        ex.push({ type: 'speak', prompt: word.a, answer: word.t, speakText: word.script || word.t, word: word });
      });
    }

    // درس المراجعة الشامل (checkpoint): أضف لعبة "طابق الأزواج"
    if (opts.checkpoint && words.length >= 4) {
      var pairWords = sample(words, Math.min(4, words.length));
      ex.unshift({ type: 'match', pairs: pairWords.map(function (p) { return { t: p.script || p.t, a: p.a, key: p.t }; }) });
    }

    ex = shuffle(ex);
    // ثبّت لعبة "طابق" في البداية لو موجودة (أفضل لتجربة المستخدم)
    ex.sort(function (a) { return a.type === 'match' ? -1 : 0; });

    var cap = opts.checkpoint ? 18 : 10;
    return ex.slice(0, cap);
  }

  function buildReviewSet(langCode) {
    var pool = Data.allWords(langCode);
    var due = Store.dueWords(langCode, pool);
    var known = Store.knownWords(langCode, pool);
    var chosen = due.length >= 5 ? due : sample(known, Math.min(known.length, 8));
    if (!chosen.length) return [];
    return generateExercises(chosen.slice(0, 10), langCode, {});
  }

  function checkAnswer(exercise, given) {
    if (exercise.type === 'speak') {
      return Speech.similarity(norm(given), norm(exercise.answer)) >= 0.55;
    }
    return norm(given) === norm(exercise.answer);
  }

  global.LessonEngine = {
    buildNodes: buildNodes,
    generateExercises: generateExercises,
    buildReviewSet: buildReviewSet,
    checkAnswer: checkAnswer,
    norm: norm,
    shuffle: shuffle
  };
})(window);

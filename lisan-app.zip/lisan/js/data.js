/* =========================================================
   لسان — بيانات اللغات والمقررات والكلمات
   كل كلمة: t (النص بالهدف) / a (المعنى بالعربية)
             et/ea (جملة مثال بالهدف/بالعربية) — اختياري
             script (الشكل الأصلي للكتابة، لو مختلف عن t) — اختياري
   ========================================================= */
(function (global) {
  'use strict';

  var LANGUAGES = [
    { code: 'en', name: 'الإنجليزية',  flag: '🇬🇧', speech: 'en-US', color: '#1cb0f6' },
    { code: 'fr', name: 'الفرنسية',    flag: '🇫🇷', speech: 'fr-FR', color: '#5b6ee1' },
    { code: 'es', name: 'الإسبانية',   flag: '🇪🇸', speech: 'es-ES', color: '#ff9600' },
    { code: 'de', name: 'الألمانية',   flag: '🇩🇪', speech: 'de-DE', color: '#8b5e34' },
    { code: 'tr', name: 'التركية',     flag: '🇹🇷', speech: 'tr-TR', color: '#e6473e' },
    { code: 'ja', name: 'اليابانية',   flag: '🇯🇵', speech: 'ja-JP', color: '#d81b60' }
  ];

  function u(id, title, icon, words) { return { id: id, title: title, icon: icon, words: words }; }
  function w(t, a, et, ea, script) { return { t: t, a: a, et: et || '', ea: ea || '', script: script || '' }; }

  var COURSES = {

    en: [
      u('en-1', 'أساسيات', '👋', [
        w('hello', 'مرحبًا', 'Hello! How are you?', 'مرحبًا! كيف حالك؟'),
        w('goodbye', 'وداعًا', 'Goodbye, see you soon.', 'وداعًا، أراك قريبًا.'),
        w('please', 'من فضلك', 'Please, sit down.', 'من فضلك، اجلس.'),
        w('thank you', 'شكرًا', 'Thank you very much.', 'شكرًا جزيلاً.'),
        w('yes', 'نعم', 'Yes, I agree.', 'نعم، أنا موافق.'),
        w('no', 'لا', "No, I don't want it.", 'لا، لا أريده.'),
        w('sorry', 'آسف', 'Sorry, I am late.', 'آسف، أنا متأخر.'),
        w('name', 'اسم', 'What is your name?', 'ما اسمك؟')
      ]),
      u('en-2', 'أشخاص وعائلة', '👪', [
        w('I', 'أنا', 'I am a student.', 'أنا طالب.'),
        w('you', 'أنتَ', 'You are my friend.', 'أنتَ صديقي.'),
        w('family', 'عائلة', 'I love my family.', 'أحب عائلتي.'),
        w('mother', 'أم', 'My mother is kind.', 'أمي طيبة.'),
        w('father', 'أب', 'My father works hard.', 'أبي يعمل بجد.'),
        w('brother', 'أخ', 'My brother is tall.', 'أخي طويل.'),
        w('sister', 'أخت', 'My sister is smart.', 'أختي ذكية.'),
        w('friend', 'صديق', 'He is my best friend.', 'هو أفضل صديق لي.')
      ]),
      u('en-3', 'طعام وشراب', '🍎', [
        w('water', 'ماء', 'I drink water every day.', 'أشرب الماء كل يوم.'),
        w('bread', 'خبز', 'The bread is fresh.', 'الخبز طازج.'),
        w('apple', 'تفاحة', 'She is eating an apple.', 'هي تأكل تفاحة.'),
        w('milk', 'حليب', 'Children need milk.', 'الأطفال يحتاجون الحليب.'),
        w('coffee', 'قهوة', 'I like coffee in the morning.', 'أحب القهوة في الصباح.'),
        w('rice', 'أرز', 'We cook rice for lunch.', 'نطبخ الأرز للغداء.'),
        w('food', 'طعام', 'The food is delicious.', 'الطعام لذيذ.'),
        w('eat', 'يأكل', "Let's eat together.", 'هيا نأكل معًا.')
      ]),
      u('en-4', 'أماكن وتنقل', '🚗', [
        w('house', 'منزل', 'This is my house.', 'هذا منزلي.'),
        w('school', 'مدرسة', 'The school is near here.', 'المدرسة قريبة من هنا.'),
        w('city', 'مدينة', 'Cairo is a big city.', 'القاهرة مدينة كبيرة.'),
        w('street', 'شارع', 'Cross the street carefully.', 'اعبر الشارع بحذر.'),
        w('car', 'سيارة', 'He has a new car.', 'لديه سيارة جديدة.'),
        w('train', 'قطار', 'The train is fast.', 'القطار سريع.'),
        w('airport', 'مطار', 'We are going to the airport.', 'نحن ذاهبون إلى المطار.'),
        w('go', 'يذهب', 'I go to work by bus.', 'أذهب إلى العمل بالحافلة.')
      ]),
      u('en-5', 'وقت وأرقام', '⏰', [
        w('one', 'واحد'), w('two', 'اثنان'), w('three', 'ثلاثة'),
        w('four', 'أربعة'), w('five', 'خمسة'),
        w('today', 'اليوم', 'Today is a beautiful day.', 'اليوم يوم جميل.'),
        w('tomorrow', 'غدًا', 'See you tomorrow.', 'أراك غدًا.'),
        w('morning', 'صباح', 'Good morning!', 'صباح الخير!')
      ]),
      u('en-6', 'أفعال يومية', '🏃', [
        w('work', 'يعمل', 'I work in an office.', 'أعمل في مكتب.'),
        w('sleep', 'ينام', 'The baby is sleeping.', 'الطفل نائم.'),
        w('read', 'يقرأ', 'I read books at night.', 'أقرأ الكتب ليلاً.'),
        w('write', 'يكتب', 'She writes a letter.', 'هي تكتب رسالة.'),
        w('speak', 'يتحدث', 'He speaks English well.', 'هو يتحدث الإنجليزية جيدًا.'),
        w('play', 'يلعب', 'Children play in the park.', 'الأطفال يلعبون في الحديقة.'),
        w('like', 'يحب', 'I like this song.', 'أحب هذه الأغنية.'),
        w('want', 'يريد', 'What do you want?', 'ماذا تريد؟')
      ])
    ],

    fr: [
      u('fr-1', 'أساسيات', '👋', [
        w('bonjour', 'مرحبًا', 'Bonjour, ça va?', 'مرحبًا، كيف الحال؟'),
        w('au revoir', 'وداعًا', 'Au revoir, à bientôt.', 'وداعًا، إلى اللقاء.'),
        w('merci', 'شكرًا', 'Merci beaucoup.', 'شكرًا جزيلاً.'),
        w("s'il vous plaît", 'من فضلك', "Un café, s'il vous plaît.", 'قهوة من فضلك.'),
        w('oui', 'نعم'), w('non', 'لا'),
        w('pardon', 'آسف', 'Pardon, je suis en retard.', 'آسف، أنا متأخر.'),
        w('nom', 'اسم', 'Quel est ton nom?', 'ما اسمك؟')
      ]),
      u('fr-2', 'أشخاص وعائلة', '👪', [
        w('je', 'أنا'), w('tu', 'أنتَ'),
        w('famille', 'عائلة', "J'aime ma famille.", 'أحب عائلتي.'),
        w('mère', 'أم'), w('père', 'أب'),
        w('ami', 'صديق', 'Il est mon ami.', 'هو صديقي.')
      ]),
      u('fr-3', 'طعام وشراب', '🍎', [
        w('eau', 'ماء', "Je bois de l'eau.", 'أشرب الماء.'),
        w('pain', 'خبز'), w('pomme', 'تفاحة'),
        w('café', 'قهوة', "J'aime le café.", 'أحب القهوة.'),
        w('manger', 'يأكل', 'Nous mangeons ensemble.', 'نأكل معًا.')
      ])
    ],

    es: [
      u('es-1', 'أساسيات', '👋', [
        w('hola', 'مرحبًا', '¡Hola! ¿Cómo estás?', 'مرحبًا! كيف حالك؟'),
        w('adiós', 'وداعًا', 'Adiós, hasta pronto.', 'وداعًا، إلى اللقاء.'),
        w('gracias', 'شكرًا', 'Muchas gracias.', 'شكرًا جزيلاً.'),
        w('por favor', 'من فضلك', 'Un café, por favor.', 'قهوة من فضلك.'),
        w('sí', 'نعم'), w('no', 'لا'),
        w('lo siento', 'آسف', 'Lo siento, llego tarde.', 'آسف، أنا متأخر.'),
        w('nombre', 'اسم', '¿Cómo te llamas?', 'ما اسمك؟')
      ]),
      u('es-2', 'أشخاص وعائلة', '👪', [
        w('yo', 'أنا'), w('tú', 'أنتَ'),
        w('familia', 'عائلة', 'Amo a mi familia.', 'أحب عائلتي.'),
        w('madre', 'أم'), w('padre', 'أب'),
        w('amigo', 'صديق', 'Él es mi amigo.', 'هو صديقي.')
      ]),
      u('es-3', 'طعام وشراب', '🍎', [
        w('agua', 'ماء', 'Bebo agua.', 'أشرب الماء.'),
        w('pan', 'خبز'), w('manzana', 'تفاحة'),
        w('café', 'قهوة', 'Me gusta el café.', 'أحب القهوة.'),
        w('comer', 'يأكل', 'Vamos a comer.', 'هيا نأكل.')
      ])
    ],

    de: [
      u('de-1', 'أساسيات', '👋', [
        w('hallo', 'مرحبًا', "Hallo, wie geht's?", 'مرحبًا، كيف حالك؟'),
        w('tschüss', 'وداعًا', 'Tschüss, bis bald.', 'وداعًا، إلى اللقاء.'),
        w('danke', 'شكرًا', 'Danke schön.', 'شكرًا جزيلاً.'),
        w('bitte', 'من فضلك', 'Ein Kaffee, bitte.', 'قهوة من فضلك.'),
        w('ja', 'نعم'), w('nein', 'لا'),
        w('name', 'اسم', 'Wie heißt du?', 'ما اسمك؟')
      ]),
      u('de-2', 'أشخاص وعائلة', '👪', [
        w('ich', 'أنا'), w('du', 'أنتَ'),
        w('Familie', 'عائلة', 'Ich liebe meine Familie.', 'أحب عائلتي.'),
        w('Mutter', 'أم'), w('Vater', 'أب'),
        w('Freund', 'صديق', 'Er ist mein Freund.', 'هو صديقي.'),
        w('Wasser', 'ماء', 'Ich trinke Wasser.', 'أشرب الماء.')
      ])
    ],

    tr: [
      u('tr-1', 'أساسيات', '👋', [
        w('merhaba', 'مرحبًا', 'Merhaba, nasılsın?', 'مرحبًا، كيف حالك؟'),
        w('hoşça kal', 'وداعًا', 'Hoşça kal, görüşürüz.', 'وداعًا، إلى اللقاء.'),
        w('teşekkürler', 'شكرًا', 'Çok teşekkürler.', 'شكرًا جزيلاً.'),
        w('lütfen', 'من فضلك', 'Bir kahve, lütfen.', 'قهوة من فضلك.'),
        w('evet', 'نعم'), w('hayır', 'لا'),
        w('isim', 'اسم', 'Adın ne?', 'ما اسمك؟')
      ]),
      u('tr-2', 'أشخاص وعائلة', '👪', [
        w('ben', 'أنا'), w('sen', 'أنتَ'),
        w('aile', 'عائلة', 'Ailemi seviyorum.', 'أحب عائلتي.'),
        w('anne', 'أم'), w('baba', 'أب'),
        w('arkadaş', 'صديق', 'O benim arkadaşım.', 'هو صديقي.'),
        w('su', 'ماء', 'Su içiyorum.', 'أشرب الماء.')
      ])
    ],

    ja: [
      u('ja-1', 'أساسيات', '👋', [
        w('konnichiwa', 'مرحبًا', '', '', 'こんにちは'),
        w('sayounara', 'وداعًا', '', '', 'さようなら'),
        w('arigatou', 'شكرًا', '', '', 'ありがとう'),
        w('onegaishimasu', 'من فضلك', '', '', 'お願いします'),
        w('hai', 'نعم', '', '', 'はい'),
        w('iie', 'لا', '', '', 'いいえ'),
        w('namae', 'اسم', '', '', '名前')
      ]),
      u('ja-2', 'أشخاص وعائلة', '👪', [
        w('watashi', 'أنا', '', '', '私'),
        w('anata', 'أنتَ', '', '', 'あなた'),
        w('kazoku', 'عائلة', '', '', '家族'),
        w('haha', 'أم', '', '', '母'),
        w('chichi', 'أب', '', '', '父'),
        w('tomodachi', 'صديق', '', '', '友達'),
        w('mizu', 'ماء', '', '', '水')
      ])
    ]
  };

  function courseFor(code) { return COURSES[code] || []; }

  function allWords(code) {
    var out = [];
    var units = courseFor(code);
    for (var i = 0; i < units.length; i++) {
      for (var j = 0; j < units[i].words.length; j++) out.push(units[i].words[j]);
    }
    return out;
  }

  function langMeta(code) {
    for (var i = 0; i < LANGUAGES.length; i++) if (LANGUAGES[i].code === code) return LANGUAGES[i];
    return null;
  }

  global.Data = {
    LANGUAGES: LANGUAGES,
    courseFor: courseFor,
    allWords: allWords,
    langMeta: langMeta
  };
})(window);
